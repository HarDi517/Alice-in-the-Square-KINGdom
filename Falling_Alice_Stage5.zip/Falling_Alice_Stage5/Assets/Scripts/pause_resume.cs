﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pause_resume : MonoBehaviour
{
    private GameObject pause;
    private GameObject panel;
    private int time = 3;
    void Start()
    {
        pause = GameObject.Find("Canvas").transform.Find("Pause").gameObject;
        panel = GameObject.Find("Canvas").transform.Find("Panel").gameObject;
    }

    void Update()
    {
        
    }
    public void ActivePause()
    {
        Time.timeScale = 0f;
        panel.SetActive(true);
        pause.SetActive(true)
;    }
    public void ActiveContinue()
    {
        StartCoroutine(wait(time));
        panel.SetActive(false);
        pause.SetActive(true);
    }
    IEnumerator wait(int time)
    {
        while (time > 0)
        {
            time -= 1;
            yield return new WaitForSecondsRealtime(1f);
        }
        Time.timeScale = 1f;
    }
}
