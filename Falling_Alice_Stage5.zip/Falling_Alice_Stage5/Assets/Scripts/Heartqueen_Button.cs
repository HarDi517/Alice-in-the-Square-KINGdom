﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Heartqueen_Button : MonoBehaviour
{
    public GameObject[] warn = new GameObject[3];
    public GameObject[] attack = new GameObject[3];
    public GameObject[] heartqueen = new GameObject[3];
    public Sprite heartqueen_sprites1;
    public Sprite heartqueen_sprites2;
    public Vector3[] end = new Vector3[3];
    Vector3[] start = new Vector3[3];
    int random1, random2;
    void Start()
    {
        
    }
    void Update()
    {

    }
    public void Heartqueen_onClick()
    {
        StartCoroutine(warn_sec(0.5f, end, 2));
    }
    IEnumerator warn_sec(float duration, Vector3[] end, int time)
    {
        while (time > 0)
        {
            time -= 1;
            random1 = Random.Range(0, 3);
            random2 = Random.Range(0, 3);
            if (random1 == random2)
            {
                WaitForEndOfFrame wait2 = new WaitForEndOfFrame();
                start[random1] = heartqueen[random1].transform.localPosition;
                float elapsed2 = 0.0f;
                while (elapsed2 < duration)
                {
                    elapsed2 += Time.deltaTime;
                    heartqueen[random1].transform.localPosition = Vector3.Lerp(start[random1], end[random1], elapsed2 / duration);
                    yield return wait2;
                }
                heartqueen[random1].transform.localPosition = end[random1];
                warn[random1].SetActive(true);
                yield return new WaitForSecondsRealtime(1f);
                warn[random1].SetActive(false);
                yield return new WaitForSecondsRealtime(0.5f);
                heartqueen[random1].GetComponent<SpriteRenderer>().sprite = heartqueen_sprites1;
                attack[random1].SetActive(true);
                yield return new WaitForSecondsRealtime(1f);
                heartqueen[random1].GetComponent<SpriteRenderer>().sprite = heartqueen_sprites2;
                attack[random1].SetActive(false);
                heartqueen[random1].transform.localPosition = start[random1];
            }
            else
            {
                WaitForEndOfFrame wait = new WaitForEndOfFrame();
                start[random1] = heartqueen[random1].transform.localPosition;
                start[random2] = heartqueen[random2].transform.localPosition;
                float elapsed = 0.0f;
                while (elapsed < duration)
                {
                    elapsed += Time.deltaTime;
                    heartqueen[random1].transform.localPosition = Vector3.Lerp(start[random1], end[random1], elapsed / duration);
                    heartqueen[random2].transform.localPosition = Vector3.Lerp(start[random2], end[random2], elapsed / duration);
                    yield return wait;
                }
                heartqueen[random1].transform.localPosition = end[random1];
                heartqueen[random2].transform.localPosition = end[random2];
                warn[random1].SetActive(true);
                warn[random2].SetActive(true);
                yield return new WaitForSecondsRealtime(1f);
                warn[random1].SetActive(false);
                warn[random2].SetActive(false);
                yield return new WaitForSecondsRealtime(0.5f);
                heartqueen[random1].GetComponent<SpriteRenderer>().sprite = heartqueen_sprites1;
                heartqueen[random2].GetComponent<SpriteRenderer>().sprite = heartqueen_sprites1;
                attack[random1].SetActive(true);
                attack[random2].SetActive(true);
                yield return new WaitForSecondsRealtime(1f);
                heartqueen[random1].GetComponent<SpriteRenderer>().sprite = heartqueen_sprites2;
                heartqueen[random2].GetComponent<SpriteRenderer>().sprite = heartqueen_sprites2;
                attack[random1].SetActive(false);
                attack[random2].SetActive(false);
                heartqueen[random1].transform.localPosition = start[random1];
                heartqueen[random2].transform.localPosition = start[random2];
            }
        }
    }
}
