﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chatting_button : MonoBehaviour
{
    public GameObject deadline;
    public GameObject chat;
    public Vector3 loc;
    Vector3 present_loc;
    public int check;
    void Start()
    {
        check = 1;
        present_loc = deadline.transform.localPosition;
    }
    void Update()
    {
        
    }
    public void Chatting_onClick()
    {
        StartCoroutine(wait(1));
    }
    IEnumerator wait_sec(int Wait, float t)
    {
        while (Wait > 0)
        {
            Wait -= 1;
            yield return new WaitForSecondsRealtime(t);
        }
        yield break;
    }
    IEnumerator wait(int Wait)
    {
        check = 0;
        chat.GetComponent<chats>().time /= 3;
        yield return StartCoroutine(wait_sec(1, 0.5f));
        deadline.transform.localPosition = loc;
        while (Wait > 0)
        {
            Wait -= 1;
            yield return new WaitForSecondsRealtime(6f);
        }
        deadline.transform.localPosition = present_loc;
        chat.GetComponent<chats>().time *= 3;
        check = 1;
    }
}
