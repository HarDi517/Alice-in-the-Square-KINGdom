﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Choose_item : MonoBehaviour
{
    public GameObject alice;
    public GameObject right_button, left_button;
    //
    public GameObject[] items1 = new GameObject[4];
    public GameObject[] items2 = new GameObject[4];
    // switch --> 0
    public GameObject knight;
    public GameObject knife;
    public GameObject knife_angle;
    Vector3 start, end;
    // switch --> 1
    public GameObject[] spears = new GameObject[2];
    Vector3 start1, start2;
    Vector3 start_spears1, start_spears2;
    // switch -->2
    public GameObject penetrate;
    //
    Button[] item_buttons1 = new Button[4];
    Button[] item_buttons2 = new Button[4];
    //
    int random1, random2, random;
    int check;
    float duration;
    void Start()
    {
        alice = GameObject.Find("Alice");
        right_button = GameObject.Find("Canvas_chat_and_button").transform.Find("Right_Button").gameObject;
        left_button = GameObject.Find("Canvas_chat_and_button").transform.Find("Left_Button").gameObject;
        for (int i = 0; i < 4; i++)
        {
            item_buttons1[i] = items1[i].GetComponent<Button>();
            items1[i].SetActive(false);
        }
        for (int i = 0; i < 4; i++)
        {
            item_buttons2[i] = items2[i].GetComponent<Button>();
            items2[i].SetActive(false);
        }
        check = 0;   // 버튼 눌렀는지 안눌렀는지 판단
        //밑으로 두줄 --> 기사에서 스타트랑 엔드
        start = knight.transform.localPosition;
        end = new Vector3(start.x - 3.3f, start.y, start.z);
        //밑으로 네줄 --> 창에서 스타트
        start1 = spears[0].transform.localPosition;
        start2 = spears[1].transform.localPosition;
        start_spears1 = spears[0].transform.localPosition;
        start_spears2 = spears[1].transform.localPosition;
        StartCoroutine(choose_now(1));
    }
    void Update()
    {

    }
    public void check_button_press()
    {
        check = 1;
    }
    IEnumerator choose_now(int time)
    {
        while (time > 0)
        {
            yield return new WaitForSecondsRealtime(3f);
            time -= 1;
            for (int i = 0; i < 20; i++)
            {
                random1 = Random.Range(0, 4);
                random2 = Random.Range(0, 4);
                random = Random.Range(0, 3);
                //case 0은 기사!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                if (random == 0)
                {
                    knife.GetComponent<PolygonCollider2D>().enabled = false;
                    WaitForEndOfFrame wait = new WaitForEndOfFrame();
                    float elapsed2 = 0.0f;
                    duration = 1f;
                    while (elapsed2 < duration)
                    {
                        elapsed2 += Time.deltaTime;
                        knight.transform.localPosition = Vector3.Lerp(start, end, elapsed2 / duration);
                        yield return wait;
                    }
                    knight.transform.localPosition = end;
                    items1[random1].SetActive(true);
                    items2[random2].SetActive(true);
                    yield return new WaitForSecondsRealtime(2f);
                    items1[random1].SetActive(false);
                    items2[random2].SetActive(false);
                    if (check == 0)
                    {
                        knife.GetComponent<PolygonCollider2D>().enabled = true;
                        alice.transform.position = new Vector3(0f, 3f, -1f);
                        right_button.GetComponent<button_right_ctrl>().enabled = false;
                        left_button.GetComponent<button_left_ctrl>().enabled = false;
                        WaitForEndOfFrame wait2 = new WaitForEndOfFrame();
                        elapsed2 = 0.0f;
                        duration = 1f;
                        while (elapsed2 < duration)
                        {
                            elapsed2 += Time.deltaTime;
                            knife_angle.transform.Rotate(new Vector3(0f, 0f, 2f));
                            yield return wait2;
                        }
                        WaitForEndOfFrame wait3 = new WaitForEndOfFrame();
                        elapsed2 = 0.0f;
                        while (elapsed2 < duration)
                        {
                            elapsed2 += Time.deltaTime;
                            knife_angle.transform.Rotate(new Vector3(0f, 0f, -2f));
                            yield return wait3;
                        }
                        WaitForEndOfFrame wait4 = new WaitForEndOfFrame();
                        elapsed2 = 0.0f;
                        duration = 1f;
                        while (elapsed2 < duration)
                        {
                            elapsed2 += Time.deltaTime;
                            knight.transform.localPosition = Vector3.Lerp(end, start, elapsed2 / duration);
                            yield return wait4;
                        }
                        knight.transform.localPosition = start;
                        knife_angle.transform.rotation = Quaternion.Euler(new Vector3(0f, 0f, 20f));
                        right_button.GetComponent<button_right_ctrl>().enabled = true;
                        left_button.GetComponent<button_left_ctrl>().enabled = true;
                        yield return new WaitForSecondsRealtime(5f);
                    }
                    else
                    {
                        WaitForEndOfFrame wait4 = new WaitForEndOfFrame();
                        elapsed2 = 0.0f;
                        duration = 1f;
                        while (elapsed2 < duration)
                        {
                            elapsed2 += Time.deltaTime;
                            knight.transform.localPosition = Vector3.Lerp(end, start, elapsed2 / duration);
                            yield return wait4;
                        }
                        knight.transform.localPosition = start;
                        knife.GetComponent<PolygonCollider2D>().enabled = true;
                        yield return new WaitForSecondsRealtime(6f);
                    }
                    check = 0;
                }
                //case 1은 양 옆 창!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                else if (random == 1)
                {
                    Vector3 end1, end2;
                    int check_spear = 0;
                    for (int j = 0; j < 4; j++)
                    {
                        WaitForEndOfFrame wait5 = new WaitForEndOfFrame();
                        if (check_spear == 1)
                        {
                            end1 = new Vector3(start1.x + 4f, start1.y, start1.z);
                            end2 = new Vector3(start2.x - 4f, start2.y, start2.z);
                            check_spear = 0;
                        }
                        else
                        {
                            end1 = new Vector3(start1.x - 4f, start1.y, start1.z);
                            end2 = new Vector3(start2.x + 4f, start2.y, start2.z);
                            check_spear = 1;
                        }
                        float elapsed3 = 0.0f;
                        duration = 0.5f;
                        while (elapsed3 < duration)
                        {
                            elapsed3 += Time.deltaTime;
                            spears[0].transform.localPosition = Vector3.Lerp(start1, end1, elapsed3 / duration);
                            spears[1].transform.localPosition = Vector3.Lerp(start2, end2, elapsed3 / duration);
                            yield return wait5;
                        }
                        spears[0].transform.localPosition = end1;
                        spears[1].transform.localPosition = end2;
                        start1 = end1;
                        start2 = end2;
                    }
                    items1[random1].SetActive(true);
                    items2[random2].SetActive(true);
                    yield return new WaitForSecondsRealtime(2f);
                    items1[random1].SetActive(false);
                    items2[random2].SetActive(false);
                    if (check == 0)
                    {
                        Vector3 end_spears1, end_spears2;
                        end_spears1 = new Vector3(start_spears1.x - 9f, start_spears1.y, start_spears1.z);
                        end_spears2 = new Vector3(start_spears2.x + 9f, start_spears2.y, start_spears2.z);
                        WaitForEndOfFrame wait6 = new WaitForEndOfFrame();
                        float elapsed4 = 0.0f;
                        duration = 1f;
                        while (elapsed4 < duration)
                        {
                            elapsed4 += Time.deltaTime;
                            spears[0].transform.localPosition = Vector3.Lerp(start_spears1, end_spears1, elapsed4 / duration);
                            spears[1].transform.localPosition = Vector3.Lerp(start_spears2, end_spears2, elapsed4 / duration);
                            yield return wait6;
                        }
                        spears[0].transform.localPosition = end_spears1;
                        spears[1].transform.localPosition = end_spears2;
                        WaitForEndOfFrame wait7 = new WaitForEndOfFrame();
                        float elapsed5 = 0.0f;
                        duration = 1f;
                        while (elapsed5 < duration)
                        {
                            elapsed5 += Time.deltaTime;
                            spears[0].transform.localPosition = Vector3.Lerp(end_spears1, start_spears1, elapsed5 / duration);
                            spears[1].transform.localPosition = Vector3.Lerp(end_spears2, start_spears2, elapsed5 / duration);
                            yield return wait7;
                        }
                        spears[0].transform.localPosition = start_spears1;
                        spears[1].transform.localPosition = start_spears2;
                        yield return new WaitForSecondsRealtime(5f);
                    }
                    else
                    {
                        yield return new WaitForSecondsRealtime(6f);
                    }
                    check = 0;
                }
                //case 2은 관통 창!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                else if (random == 2)
                {
                    Debug.Log("e");
                }
            }
        }
    }
}

