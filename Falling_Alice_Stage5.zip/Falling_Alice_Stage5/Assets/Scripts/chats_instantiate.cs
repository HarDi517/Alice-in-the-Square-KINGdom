﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class chats_instantiate : MonoBehaviour
{
    public Sprite[] sprites = new Sprite[9];
    public GameObject[] buttons = new GameObject[2];
    Button button;
    GameObject chat;
    private GameObject ob;
    private SpriteRenderer spriteRenderer;
    private int random;
    public float time;
    int i;
    public string start_idx;
    int check1, check2;
    void Start()
    {
        buttons[0] = GameObject.Find("Canvas_itemButton").transform.Find("itemButton1_2").gameObject;
        buttons[1] = GameObject.Find("Canvas_itemButton").transform.Find("itemButton2_2").gameObject;
        chat = GameObject.Find("Chatting");
        i = chat.GetComponent<chats>().i;
        time = 1f;
        ob = gameObject.transform.Find("Profile_Ins").gameObject;
        spriteRenderer = ob.GetComponent<SpriteRenderer>();
        random = Random.Range(0, 9);
        spriteRenderer.sprite = sprites[random];
    }

    void Update()
    {
        if (buttons[0].activeSelf == true)
        {
            check1 = buttons[0].GetComponent<Chatting_button>().check;
            if (check1 == 0)
            {
                time = 3f;
            }
            else if (check1 == 1)
            {
                time = 1f;
            }
            if (buttons[1].activeSelf == true)
            {
                check2 = buttons[1].GetComponent<Chatting_button>().check;
                if (check2 == 0)
                {
                    time = 3f;
                }
                else if (check2 == 1)
                {
                    time = 1f;
                }
            }
        }
        else if (buttons[1].activeSelf == true)
        {
            check2 = buttons[1].GetComponent<Chatting_button>().check;
            if (check2 == 0)
            {
                time = 3f;
            }
            else if (check2 == 1)
            {
                time = 1f;
            }
        }
        transform.position = new Vector3(transform.position.x, transform.position.y + time * Time.deltaTime, transform.position.z);
        transform.name = i.ToString();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Deadline")
        {
            Destroy(gameObject);
            start_idx = gameObject.name;
        }
    }
}
