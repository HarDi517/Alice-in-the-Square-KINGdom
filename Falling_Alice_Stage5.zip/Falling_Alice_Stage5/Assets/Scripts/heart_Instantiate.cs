﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class heart_Instantiate : MonoBehaviour
{
    Vector3 start, end;
    float duration;
    int check;
    void Start()
    {
        duration = 0.5f;
        StartCoroutine(move());
        check = 0;
    }
    void Update()
    {

    }
    //        transform.Rotate(new Vector3(0f, 0f, Mathf.PI / 4));
    //      transform.Rotate(new Vector3(0f, 0f, Mathf.PI / 4));
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Heartline")
        {
            Destroy(gameObject);
        }
    }
    IEnumerator move()
    {
        while (true)
        {
            WaitForEndOfFrame wait = new WaitForEndOfFrame();
            start = transform.localPosition;
            if (check == 1)
            {
                end = new Vector3(start.x + 0.7f, start.y + 1, start.z);
                check = 0;
            }
            else
            {
                end = new Vector3(-start.x + 0.7f, start.y + 1, start.z);
                check = 1;
            }
            float elapsed2 = 0.0f;
            while (elapsed2 < duration)
            {
                elapsed2 += Time.deltaTime;
                transform.localPosition = Vector3.Lerp(start, end, elapsed2 / duration);
                yield return wait;
            }
            transform.localPosition = end;
        }
    }
}



//       Vector3 v = pos;
//       v.x += delta * Mathf.Sin(Time.time * speed);
//       v.y += delta * Mathf.Sin(Time.time * speed);
//       transform.position = v;
/*
 *     IEnumerator move_LR()
    {
        int change = 1;
        float x = speed * Mathf.Sin(Mathf.PI / 4) * change;
        float y = speed * Mathf.Sin(Mathf.PI / 4);
        push = new Vector2(x, y);
        while (true)
        {
            GetComponent<Rigidbody2D>().AddForce(push);
            yield return new WaitForSecondsRealtime(0.5f);
            change *= 4;
            x = -x;
 //           GetComponent<Rigidbody2D>().AddForce(new Vector2(-speed * Mathf.Sin(Mathf.PI / 4) * change, speed * Mathf.Sin(Mathf.PI / 4)));
        }
    }
 */
