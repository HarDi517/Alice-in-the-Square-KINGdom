﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class button_right_ctrl : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public int speed;
    public GameObject alice;
    void Start()
    {
        alice = GameObject.Find("Alice");
    }
    void Update()
    {
        
    }
    public void OnPointerDown(PointerEventData eventData)
    {
        alice.GetComponent<Rigidbody2D>().velocity = Vector2.right * speed * Time.deltaTime;
    }
    public void OnPointerUp(PointerEventData eventData)
    {
        alice.GetComponent<Rigidbody2D>().velocity = Vector2.right * 0 * Time.deltaTime;
    }
}
