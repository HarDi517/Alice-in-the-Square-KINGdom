﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class obstacles : MonoBehaviour
{
    public GameObject alice;
    public GameObject[] heart = new GameObject[5];
    public GameObject you_die;
    public int i = 5;
    void Start()
    {
        alice = GameObject.Find("Alice");
        for(int i = 0; i < 5; i++)
        {
            heart[i] = GameObject.Find("heart" + (i + 1).ToString());
        }
    }

    void Update()
    {
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Obstacles" && i != 0)
        {
            heart[i - 1].GetComponent<SpriteRenderer>().enabled = false;
    //        Destroy(heart[i - 1]);
            i--;
            if (i == 0)
            {
                Time.timeScale = 0;
            }
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Obstacles" && i != 0)
        {
            Destroy(heart[i - 1]);
            i--;
            if (i == 0)
            {
                Time.timeScale = 0;
            }
        }
    }
}
