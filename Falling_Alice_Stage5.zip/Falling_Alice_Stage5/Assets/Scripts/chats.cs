﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class chats : MonoBehaviour
{
    public GameObject prefab;
    public float time;
    public int i;
    void Start()
    {
        i = 0;
        time = 47f * Time.deltaTime;
        StartCoroutine(wait());
    }
    void Update()
    {

    }
    IEnumerator wait()
    {
        while (true)
        {
            yield return new WaitForSeconds(time);
            Instantiate(prefab, new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity, transform);
            i++;
        }
    }
}
