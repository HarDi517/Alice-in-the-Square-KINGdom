﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Heart : MonoBehaviour
{
    public GameObject prefab;
    public float time;
    void Start()
    {
        time = 20f * Time.deltaTime;
        StartCoroutine(wait());
    }
    void Update()
    {
        
    }
    IEnumerator wait()
    {
        while (true)
        {
            yield return new WaitForSeconds(time);
            Instantiate(prefab, new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity, transform);
        }
    }
}
